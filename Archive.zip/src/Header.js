// Header.js
import React, { Component } from "react";
import {
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Menu,
  MenuItem,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/MenuOutlined";

import { useNavigate } from "react-router-dom";

class Header extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isMenuOpen: false,
      clickedMenuItem: null,
    };
  }

  handleMenuOpen = () => {
    this.setState({ isMenuOpen: true });
  };

  handleMenuClose = () => {
    this.setState({ isMenuOpen: false });
  };

  handleMenuItemClick = (item) => {
    this.setState({ clickedMenuItem: item });
    this.props.onMenuItemClick(item); // Update selectedMenuItem in parent component
    this.handleMenuClose();
    // there should navigate to chart
    // TODO
  };

  render() {
    const { isMenuOpen, clickedMenuItem } = this.state;

    return (
      <AppBar position="static">
        <Toolbar>
          <IconButton
            size="large"
            edge="start"
            color="inherit"
            aria-label="menu"
            onClick={this.handleMenuOpen}
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton>
          <Menu
            id="menu-appbar"
            anchorOrigin={{
              vertical: "bottom",
              horizontal: "left",
            }}
            transformOrigin={{
              vertical: "top",
              horizontal: "left",
            }}
            open={isMenuOpen}
            onClose={this.handleMenuClose}
            PaperProps={{
              style: {
                color: "#fff",
                height: "100vh",
                backgroundColor: "#1976d2",
              },
            }}
          >
            <MenuItem onClick={() => this.handleMenuItemClick("Temperature")}>Temperature</MenuItem>
            <MenuItem onClick={() => this.handleMenuItemClick("Humidity")}>Humidity</MenuItem>
            <MenuItem onClick={() => this.handleMenuItemClick("Coming soon...")}>Coming soon...</MenuItem>
          </Menu>

          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            IoT Project
          </Typography>
        </Toolbar>
      </AppBar>
    );
  }
}

export default Header;


